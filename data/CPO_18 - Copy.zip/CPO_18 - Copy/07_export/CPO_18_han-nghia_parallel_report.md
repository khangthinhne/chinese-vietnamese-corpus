# Báo cáo dóng hàng CPO_18_han-nghia_parallel

- Cặp: `han-nghia`
- Số cặp xuất: **4**
- Số câu Hán: 6; số câu nghia: 5
- Phân bố kiểu dóng: {'1-1': 2, '2-2': 1, '2-1': 1}
- Bị loại khi xuất: không
- Cặp điểm thấp (cần rà soát): 1; cặp qua trang: 0
- Tự kiểm tra: không ô rỗng, không tab/xuống dòng trong vế, TSV = XLSX, không công thức/ô gộp: **đạt**

Lưu ý: điểm score chỉ để xếp hạng rà soát, không phải độ chính xác. Tỉ lệ lỗi thật phải đo bằng mẫu kiểm tra thủ công (OMISSION/ADDITION/MISSING).
