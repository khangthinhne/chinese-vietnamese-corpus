
import os

# Set before importing torch
os.environ["PYTORCH_CUDA_ALLOC_CONF"] = "expandable_segments:True"

import torch
from transformers import (
    Qwen2_5_VLForConditionalGeneration,
    AutoProcessor,
    BitsAndBytesConfig,
)
from qwen_vl_utils import process_vision_info


# ==========================================
# Configuration
# ==========================================

MODEL_ID = "syntheticbot/ocr-qwen"
PROCESSOR_ID = "Qwen/Qwen2.5-VL-7B-Instruct"

IMAGE_PATH = "data/CPO_19/02_extraction/pages/page_015.png"

MAX_NEW_TOKENS = 512
MAX_IMAGE_PIXELS = 256 * 28 * 28

assert torch.cuda.is_available(), "CUDA is not available!"

print("GPU:", torch.cuda.get_device_name(0))
print("CUDA:", torch.version.cuda)


# ==========================================
# 4-bit Quantization
# ==========================================

quantization_config = BitsAndBytesConfig(
    load_in_4bit=True,
    bnb_4bit_quant_type="nf4",
    bnb_4bit_compute_dtype=torch.float16,
    bnb_4bit_use_double_quant=True,
)


# ==========================================
# Load Model
# ==========================================

print("Loading model...")

model = Qwen2_5_VLForConditionalGeneration.from_pretrained(
    MODEL_ID,
    quantization_config=quantization_config,
    device_map="auto",
    max_memory={0: "5GiB", "cpu": "222GiB"},
    dtype=torch.float16,
    offload_folder="D:/AI_Models/offload",
    offload_state_dict=True,
)

model.eval()

print("Model loaded!")
print(
    "GPU memory:",
    round(torch.cuda.memory_allocated() / 1024**3, 2),
    "GB"
)


# ==========================================
# Load Processor
# ==========================================

processor = AutoProcessor.from_pretrained(
    PROCESSOR_ID,
    min_pixels=4 * 28 * 28,
    max_pixels=MAX_IMAGE_PIXELS,
)


# ==========================================
# OCR
# ==========================================

messages = [
    {
        "role": "user",
        "content": [
            {
                "type": "image",
                "image": IMAGE_PATH,
            },
            {
                "type": "text",
                "text": "Extract the text from this image.",
            },
        ],
    }
]

text = processor.apply_chat_template(
    messages,
    tokenize=False,
    add_generation_prompt=True,
)

image_inputs, video_inputs = process_vision_info(messages)

inputs = processor(
    text=[text],
    images=image_inputs,
    videos=video_inputs,
    padding=True,
    return_tensors="pt",
)

# With device_map="auto", input should be placed
# on the model's input embedding device.
input_device = model.get_input_embeddings().weight.device
inputs = inputs.to(input_device)

print("Running OCR...")

with torch.inference_mode():
    generated_ids = model.generate(
        **inputs,
        max_new_tokens=MAX_NEW_TOKENS,
        do_sample=False,
        use_cache=True,
    )

generated_ids_trimmed = [
    output_ids[len(input_ids):]
    for input_ids, output_ids in zip(
        inputs.input_ids,
        generated_ids,
    )
]

output_text = processor.batch_decode(
    generated_ids_trimmed,
    skip_special_tokens=True,
    clean_up_tokenization_spaces=False,
)

print("\n========== OCR RESULT ==========")
print(output_text[0])
print("================================")

print(
    "Peak GPU memory:",
    round(torch.cuda.max_memory_allocated() / 1024**3, 2),
    "GB"
)
